self.assetsManifest = {
  "version": "7Ae+Lt6s",
  "assets": [
    {
      "hash": "sha256-ytpXBcS7DWkc5q4ZfV2iKaULjF2qGdS64P7sOC+b3nM=",
      "url": "PwaRedirectTest.styles.css"
    },
    {
      "hash": "sha256-UN9ftY5DGqB/TOJLeNUItgWqQCiVPacDIedv1L4gWjw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.0ojbbnouov.wasm"
    },
    {
      "hash": "sha256-FkjkgElSNqq/LOFPfYbhWfIt0Ty74smPtIA4zXGPTyg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.y2szbxriyo.wasm"
    },
    {
      "hash": "sha256-Ltz+O6aTXDAPrZPpzIhbNDuhQcl+AXTlKMy5RsoB+FU=",
      "url": "_framework/Microsoft.AspNetCore.Components.u4s3n1txdz.wasm"
    },
    {
      "hash": "sha256-l8xuMPBIytDlsVipKcny4/V0zbAjJckJxqbtWJcncis=",
      "url": "_framework/Microsoft.Extensions.Configuration.1ezpgdlkhk.wasm"
    },
    {
      "hash": "sha256-tm6S8Zxf8NzUrUVvtojqlYELJ/ect0nKZcx8Z7/iGkI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.awg3pcndbr.wasm"
    },
    {
      "hash": "sha256-yLeqa+N7rj/oA+/DuzjYNyfXd1ErXM5krBAglzElmtc=",
      "url": "_framework/Microsoft.Extensions.Configuration.EnvironmentVariables.svkmtmeo3a.wasm"
    },
    {
      "hash": "sha256-aBvQ/hjvWjNCG089D7owVJIUPazDqP+mw4FMH7xN0Js=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.sfzkvj0etu.wasm"
    },
    {
      "hash": "sha256-2rPu9DuSGQIdVrbSY7b6RmIF5BRijpalMFuPIAIBA38=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.iud3b06spo.wasm"
    },
    {
      "hash": "sha256-ssG8bY1HJgMre03jMxpw2cTZeX5yWoUzo6wzoVbFh6A=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.y4c9scxfut.wasm"
    },
    {
      "hash": "sha256-nF2Mh8a8iAFpwk+myaFmCEMYpbwTU9lxjBizwIrzaAw=",
      "url": "_framework/Microsoft.Extensions.Hosting.Abstractions.0navi5hah5.wasm"
    },
    {
      "hash": "sha256-JMceOwb/X4RIQlb0GVufOx+0q6SoDKSH0AmxwrSfM1c=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.wtrhw04r5z.wasm"
    },
    {
      "hash": "sha256-mhyfDfp1yETuDVueSidJxvvZcMFIEgObSnA7PCk7v0E=",
      "url": "_framework/Microsoft.Extensions.Logging.ydr71rn8ee.wasm"
    },
    {
      "hash": "sha256-HeaPNmQV5vcHE2P/kUBwpPoFy9iNphhlyyvV0B1CWz8=",
      "url": "_framework/Microsoft.Extensions.Options.twkxqdh5cg.wasm"
    },
    {
      "hash": "sha256-szk+VzTSRexWqZxOvC2M+M1OQg7BryrD2sZ2SJ9UQJ0=",
      "url": "_framework/Microsoft.Extensions.Primitives.ry5if768u3.wasm"
    },
    {
      "hash": "sha256-VEB/4YtP9ySU4p2RtiTB5X0jKnexUUDF9ZO492ISjxI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.grtk0vdldj.wasm"
    },
    {
      "hash": "sha256-LI1zNHeSr+K7xLMTwA0PbtoNzcD8qPRx1nXDISkKjAI=",
      "url": "_framework/Microsoft.JSInterop.w97cbihxk8.wasm"
    },
    {
      "hash": "sha256-DK7xWX+P0BfKX+juLdgmMVAzBlRhE1n/LqwVLF93qA8=",
      "url": "_framework/PwaRedirectTest.015ulmtzto.wasm"
    },
    {
      "hash": "sha256-nlSsDxAhoP2dSiausngvwY0XOsvsBtuc3PEMqUfOfrw=",
      "url": "_framework/System.Collections.Concurrent.67mwfhexiz.wasm"
    },
    {
      "hash": "sha256-lkFvytaYb75LMfKSe+OFblUFTWdGwRw4IxdnVGDzOMc=",
      "url": "_framework/System.Collections.Immutable.ydm988cyxf.wasm"
    },
    {
      "hash": "sha256-8NfMO5D+8jTHBql84/h+4I1rzH1K3xiJ1+DdnruBlNU=",
      "url": "_framework/System.Collections.cp490as6rn.wasm"
    },
    {
      "hash": "sha256-xJ8lznwUVjdrP+Vhh1VNyfrhe4tkSk/KDGvn2wiSeKE=",
      "url": "_framework/System.ComponentModel.01uno8rfka.wasm"
    },
    {
      "hash": "sha256-VU3o+G/pYy4N6S4K2xq7m93yvnCJMLTMmJl/+Emf6j4=",
      "url": "_framework/System.Console.p7w9qa06nc.wasm"
    },
    {
      "hash": "sha256-2ClowRDPFu7hc18GdS2atWjxg7SsBpZWHhfOJFp+J9Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.kppwccx9so.wasm"
    },
    {
      "hash": "sha256-nbfbBTuTJvn6PNLWJcKFVtnfRNmkfIMTn6M4UhXCxxI=",
      "url": "_framework/System.IO.Pipelines.nvrht9ubsx.wasm"
    },
    {
      "hash": "sha256-x24os6vd5b5XYxwYjkt/gWf1f46CT1E0y1UlifMprLU=",
      "url": "_framework/System.Linq.v6tgve4j28.wasm"
    },
    {
      "hash": "sha256-4MDjVFVUowUVTdP903kSCjh4slE/ybnwGN2tYQVK7TQ=",
      "url": "_framework/System.Memory.8a3tn5y5ta.wasm"
    },
    {
      "hash": "sha256-zmaJ6UP5HLY47hlLX8dGpp2Jq0JzKjxQiYnUEhTMJ5c=",
      "url": "_framework/System.Net.Http.66z7l1mec0.wasm"
    },
    {
      "hash": "sha256-gHTK0hBTSRn0PYNheK83NA10IYzfX87D18fs9+prb20=",
      "url": "_framework/System.Net.Http.Json.k7fen8zafb.wasm"
    },
    {
      "hash": "sha256-jIKNZppt1OwWo4gnXZEFoqGEeLNWy+miWVEokw7o0dI=",
      "url": "_framework/System.Net.Primitives.sku3du6w85.wasm"
    },
    {
      "hash": "sha256-DMW2zNK+2t+IE2B6F41SANVTJ97s8AnqiveFCPS9BZQ=",
      "url": "_framework/System.Private.CoreLib.gdhwnlzoww.wasm"
    },
    {
      "hash": "sha256-6CAIHrTILjVYNRehyy4pblAmB9zVxrFixIlh4dTO0/w=",
      "url": "_framework/System.Private.Uri.kdsxbiak3g.wasm"
    },
    {
      "hash": "sha256-NdeXzbT1NDxqet+KlsaLo4CkhkFoHqATSBUEBEQSB58=",
      "url": "_framework/System.Runtime.1lk0rpz9aw.wasm"
    },
    {
      "hash": "sha256-3IlWtuYbw+wK810cK71e4P68G7lJBeOQQbOtFtB4iog=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.0bxd4j3jw4.wasm"
    },
    {
      "hash": "sha256-RU+AcPojtu3D+Eo3iKWbCbL7DFxuBOKQOgy2a6CbE9M=",
      "url": "_framework/System.Security.Cryptography.7datjp27kt.wasm"
    },
    {
      "hash": "sha256-0IkoQH4lNPJxOvabzl4yKXivLUrjCupdB9UlGuyMVtU=",
      "url": "_framework/System.Text.Encodings.Web.kzxbh649oi.wasm"
    },
    {
      "hash": "sha256-tKqI/1zBc8CABtrxdMZ42qw67MS1uJ09Mbff3zyP3h8=",
      "url": "_framework/System.Text.Json.g3t88i8kbx.wasm"
    },
    {
      "hash": "sha256-369uyMrCNsYusB03CSppSD3mYFUl74ZpjMJbN73SDf0=",
      "url": "_framework/System.Text.RegularExpressions.7m81q50lnf.wasm"
    },
    {
      "hash": "sha256-xI+0AYBllEcYNYZeds+rgnJ8l9AF245ZsJTBUmm+7RU=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XtzVQt8vk5A9LDqJQcUAK4ukFgix9LUQ0R4ojl3LkjU=",
      "url": "_framework/blazor.webassembly.js.map"
    },
    {
      "hash": "sha256-fWobN4t1Q+EYq5ZxcHWJlZKfYrBuzvkUtVEXXP04yus=",
      "url": "_framework/dotnet.99vpchllxy.js"
    },
    {
      "hash": "sha256-Yq7ZEuEt7Rl9b3Cx8r6w4pHZ7lYgZPSURC5h7731q5g=",
      "url": "_framework/dotnet.native.67mkl7h9mo.js"
    },
    {
      "hash": "sha256-WdQBTW/YTvvjUQoFsDAhhYGOLl4Dvh6mrwdvLeT8oPs=",
      "url": "_framework/dotnet.native.ng1hqcchtd.wasm"
    },
    {
      "hash": "sha256-OjXfxsYRP/cygSpkbZTiu2yEQ4kgJ7vAxM82jpdKhQ8=",
      "url": "_framework/dotnet.runtime.u7u1yxqnoc.js"
    },
    {
      "hash": "sha256-eZuX0pntrUwNrAmFCMwpxJjFA3/Myi/rW2x9mEZ+Mbg=",
      "url": "_framework/icudt_CJK.5lgyv9xn0b.dat"
    },
    {
      "hash": "sha256-SQcxb+bdx2UXUCU9tFdOWCr4Ctk64xghCnr0JGLWWKQ=",
      "url": "_framework/icudt_EFIGS.xyuimhy3ww.dat"
    },
    {
      "hash": "sha256-T8YllylpxyWp9Aq4AiF+BMAxKXqYyzWB9RA5RqY19vs=",
      "url": "_framework/icudt_no_CJK.h0en30vv0c.dat"
    },
    {
      "hash": "sha256-3Hqfdzs4KdFbjQt1BxP/mRLeCbTyjBUd8DD0lLeDqGk=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-rauQjdduJc1FWyhIvYOl9Nz8PVDvAw+Zf3taNRoO4pk=",
      "url": "images/Blazor.jpeg"
    },
    {
      "hash": "sha256-B1KruGKuOsR4eVwzGTZ0eUgjEwWgUwuvm/pwByjb3xU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-mkoRoV24jV+rCPWcHDR5awPx8VuzzJKN0ibhxZ9/WaM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-Wq4aWW1rQdJ+6oAgy1JQc9IBjHL9T3MKfXTBNqOv02c=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-Xj4HYxZBQ7qqHKBwa2EAugRS+RHWzpcTtI49vgezUSU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-exiXZNJDwucXfuje3CbXPbuS6+Ery3z9sP+pgmvh8nA=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-EPRLgpqWkahLxEn6CUjdM76RIYIw1xdHwTbeHssuj/4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-Tsbv8z6VlNgVET8xvz/yLo/v5iJHTAj2J4hkhjP1rHM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-+UW802wgVfnjaSbdwyHLlU7AVplb0WToOlvN1CnzIac=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-9Wr7Hxe8gCJDoIHh5xP29ldXvC3kN2GkifQj9c8vYx4=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-ZI01e/ns473GKvACG4McggJdxvFfFIw4xspwQiG8Ye4=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-vjdA1+zKFIMRKP9Pn8soI+PSgCxgRrtAeKr8FX2I1Eg=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
